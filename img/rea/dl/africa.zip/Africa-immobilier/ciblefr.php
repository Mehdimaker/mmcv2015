<?php 
if($_POST['liste1']=="0")
{
	echo "<script>alert(\"Veuillez chosir une region et un pays\")</script>";
	echo "<script>location.href=\"index.php\"</script>";
}
elseif($_POST['liste2']=="0")
{
	echo "<script>alert(\"Veuillez chosir une region et un pays\")</script>";
	echo "<script>location.href=\"index.php\"</script>";
}
elseif($_POST['liste3']=="0")
{
	echo "<script>alert(\"Veuillez chosir une region et un pays\")</script>";
	echo "<script>location.href=\"index.php\"</script>";
}
elseif($_POST['liste4']=="0")
{
	echo "<script>alert(\"Veuillez chosir une region et un pays\")</script>";
	echo "<script>location.href=\"index.php\"</script>";
}
elseif($_POST['liste5']=="0")
{
	echo "<script>alert(\"Veuillez chosir une region et un pays\")</script>";
	echo "<script>location.href=\"index.php\"</script>";
}
else
{  
header('Location:'.$_POST['liste1'].$_POST['liste2'].$_POST['liste3'].$_POST['liste4'].$_POST['liste5']);
}
   ?>