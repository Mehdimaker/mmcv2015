<?php
	require_once('class.detect_device.php');
	$actual_device = new detect_device();
	$actual_device->ipad = false;
	$actual_device->android = true;
	$actual_device->iphone = true;
	$actual_device->blackberry = true;
	$actual_device->desktop = false;
	$actual_device->mobileredirect = "indexmobile.php";
	$actual_device->desktopredirect = false;
	$actual_device->redirect();	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
     <title>Africa Immobilier:  Version Web EN</title>
     <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	 <link rel="stylesheet" href="styleweb.css" type="text/css" />
     <link rel="shortcut icon" href="images/favicon/favicon.ico" />    
     <script language="javascript">
	 	 
	 	function afficher_cacher(id)
	{
        if(document.getElementById(id).style.visibility=="visible")
        {
                document.getElementById(id).style.visibility="hidden"; 
        }
        else
        {
                document.getElementById(id).style.visibility="visible";
        }
        return true;
	}
	function Affiche_liste(id_ensemble_select,id_select)
{
        // S�lection du bloc contenant les s�lections li�es (id = "categorie" dans notre exemple)
        var id_ensemble_select = document.getElementById(id_ensemble_select);
        
        // S�lection de la s�lection li�e
        var id_select = document.getElementById(id_select);
   
        if(id_ensemble_select)
                        {
                                //Initialisation d'une variable pour contenir un tableau.
                                var tab = new Array();
                   
                                // Cherche les balises select inlues dans le bloc (id = "categorie" dans notre exemple) contenant les s�lections li�es  et les retourne dans un tableau
                                tab = id_ensemble_select.getElementsByTagName('select');
                                
                                var tablength = tab.length;
                                
                                // Liste les �l�ments du tableau
                                for (i=0; i < tablength; i++)        
                                        {
                                                // Met les selects en disable = true et les cache avec style.display = 'none'
                                                tab[i].disabled = true;
                                                if(id_select) tab[i].style.display = 'none';// si select est vide on ne fait rien
                                        }
                                                                
                                // Met la s�lection li�e s�lectionn� en disable = false et l'affiche avec style.display = 'inline'
                                if(id_select)
                                        {
                                                id_select.disabled = false;
                                                id_select.style.display = 'inline'; 
                                        }     
                        }

}
function appelPage(liste)
{
  window.location.href =liste.options[liste.selectedIndex].value;
}

	 </script>  
</head>

<body>
<div id="header">
	<img src="images/logo_africa_immobilier.png" class="logo" />
	<img src="images/titreen.png" class="titreen"/>
   
          	<a class="lang_en" id="bouton_texte" onclick="javascript:afficher_cacher('texte');">English
          	<img src="images/arrow.png" style="border: 0;"/></a>
        	<div id="texte">
       		<a class="lang_fr" href="indexwebfr.php">French</a>
        </div>
</div>

<div id="content">
	<div id="window">
    	<img src="images/loupe.png" class="loupe"/>
     
            		
    	<p class="titrewin">Buy a property, Rent a house or an appartment<br/>throughout Maghreb and Africa</p>
        
    	<div id="windowin">
        
        <form method="post" action="cible.php">
        <fieldset>
	 		<legend>Select Your Region</legend>
            <label>		<select name = "cat" class = "categorie" onchange = "Affiche_liste(this.className,this.value)" />
                           <option value = "">-- please, choose --</option>
                           <option value = "maghreb">Maghreb</option>
                           <option value = "central_africa">Central Africa</option>
                           <option value = "western_africa">Western Africa</option>
                           <option value = "eastern_africa">Eastern Africa</option>
                           <option value = "Southern_africa">Southern Africa</option>
                        </select>
             </label>
     	</fieldset>
       	<fieldset id="categorie">
	 		<legend >Select Your Country</legend>
            <label>
            			<select name = "liste1" id = "maghreb" style= "display:inline" disabled="disabled" >
                           	<option value = "0" selected="selected">-- please, choose --</option>
 							<option value = "http://africa-immobilier.ma">Morocco</option>                           
                        </select>     
  			
                        <select name = "liste2" id = "central_africa" >
                           	<option value = "0" selected="selected">-- please, choose --</option>
                           	<option value = "http://africa-immobilier.cm/en">Cameroon</option>        
                        </select>                           
                               
                        <select name = "liste3" id = "western_africa">      
                           	<option value = "0" selected="selected">-- please, choose --</option>
                           	<option value = "http://africa-immobilier.com/ci">Ivory Coast</option>   
                           	<option value = "http://africa-immobilier.sn">Senegal</option>   
                        </select>
                        
                        <select name = "liste4" id = "eastern_africa">
                           	<option value = "0" selected="selected">-- please, choose --</option>       
                        </select>
                        
                         <select name = "liste5" id = "Southern_africa">
                           	<option value = "0" selected="selected">-- please, choose --</option>
                        </select>
      		</label>
            
		</fieldset>
            <label><br/>
            	<input type="checkbox" value="rbinfos" name="rbinfos"/>Remember my settings info 
            </label>	
            <br/>
         <input class="continue" src="images/before.jpg" type="image" value="submit" onmouseover="javascript:this.src='images/after.jpg';"onmouseout="javascript:this.src='images/before.jpg';">
    
      </form>	
    	</div> 
       		
       </div>	
    </div>
 
<div/>

<div id="footer">
	<p><span class="footer">� Africa Immobilier 2013</span>
	<a href="http://www.facebook.com/africaimmobilier" target="_blank"><img src="images/facebook.png" align="absmiddle" style="border: 0;margin-left:30px;margin-top:-15px;width:22px;height:22px"/></a>
	<a href="http://www.twitter.com/africimmobilier" target="_blank"><img src="images/twitter.png"  align="absmiddle" style="border: 0;margin-left:4px;margin-top:-15px;width:22px;height:22px"/></a></p>
<div/>
</body>
</html> 