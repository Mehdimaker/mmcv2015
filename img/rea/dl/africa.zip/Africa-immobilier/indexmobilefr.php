<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr" lang="fr">
<head>
     <title>Africa Immobilier:  Version Mobile FR</title>
     <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
	 <link rel="stylesheet" href="stylemobile.css" type="text/css" />
	 <script type="text/javascript" >
     function afficheMenu(obj){
	
	var idMenu     = obj.id;
	var idSousMenu = 'sous' + idMenu;
	var sousMenu   = document.getElementById(idSousMenu);
	for(var i = 1; i <= 6; i++){
		if(document.getElementById('sousmenu' + i) && document.getElementById('sousmenu' + i) != sousMenu){
			document.getElementById('sousmenu' + i).style.display = "none";
		}
	}
	
	if(sousMenu){
		//alert(sousMenu.style.display);
		if(sousMenu.style.display == "block"){
			sousMenu.style.display = "none";
		}
		else{
			sousMenu.style.display = "block";
		}
	}
	
}</script>
</head>
<body>

<div id="header">
	<img src="images/mbgheaderfr.png" class="bgheader"/>
<div/>

<div id="content">
<div id="menu">
<h1>Choisissez votre r�gion</h1>
	
    <div class="menu" id="menu1" onclick="afficheMenu(this)">
	<img src="images/bgmenubefore.png" />
    <div class="titre">Maghreb</div>
	</div>
		<div id="sousmenu1" style="display:none">
			<div class="sousmenu">
			<a href="http://africa-immobilier.ma"><img src="images/ssmenubefore.png" onclick="javascript:this.src='images/ssmenuafter.png';"/> </a>
            <div class="sstitre">Maroc</div>
			</div>
		</div>
	
	<div class="menu" id="menu2" onclick="afficheMenu(this)">
	<img src="images/bgmenubefore.png"/>
    <div class="titre">Afrique Centrale</div>
	</div>
		<div id="sousmenu2" style="display:none">
			<div class="sousmenu">
			<a href="http://africa-immobilier.cm/fr">
            <img src="images/ssmenubefore.png" onclick="javascript:this.src='images/ssmenuafter.png';"/></a>
            <div class="sstitre">Cameroun</div>
			</div>
		</div>
	
	<div class="menu" id="menu3" onclick="afficheMenu(this)">
	<img src="images/bgmenubefore.png"/>
    <div class="titre">Afrique de l'ouest</div>
	</div>
    	<div id="sousmenu3" style="display:none">
			<div class="sousmenu">
			<a href="http://africa-immobilier.com/ci"><img src="images/ssmenubefore.png" onclick="javascript:this.src='images/ssmenuafter.png';"/> </a>
            <div class="sstitre">C�te d'Ivoire</div>
			</div>
			<div class="sousmenu">
			<a href="http://africa-immobilier.sn"><img src="images/ssmenubefore.png" onclick="javascript:this.src='images/ssmenuafter.png';"/> </a>
            <div class="sstitre">S�n�gal</div>
			</div>
		</div>
    
	<div class="menu" id="menu4" onclick="afficheMenu(this)">
	<img src="images/bgmenubefore.png"/>
    <div class="titre">Afrique de l'est</div>
	</div>
    	<div id="sousmenu4" style="display:none">
		</div>
    
	<div class="menu" id="menu5" onclick="afficheMenu(this)">
	<img src="images/bgmenubefore.png"/>
    <div class="titre">Afrique australe</div>
	</div>
		<div id="sousmenu5" style="display:none">
		</div>
</div>

    <div class="menulang" id="menu6" onclick="afficheMenu(this)">
	<img src="images/langbefore.jpg" onclick="javascript:this.src='images/langafter.jpg';"/>
	</div>
		<div id="sousmenu6" style="display:none">
			<div class="sousmenu">
			<img src="images/frenchok.png" />
			</div>
			<div class="sousmenu">
			<a href="indexmobileen.php"><img src="images/english.png" onclick="javascript:this.src='images/englishafter.png';"/> </a>
			</div>
		</div>

<div id="footer">
<img src="images/footer.jpg" class="footer"/>
</div>

</div>
</body>
</html> 